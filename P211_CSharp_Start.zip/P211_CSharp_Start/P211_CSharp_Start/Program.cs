﻿using System;

namespace P211_CSharp_Start
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Read numbers and loop
            //js - loosely typing
            //c# - strictly typing

            //Console.Write("Deer User, please, input a number to sum:");
            //string number = Console.ReadLine();
            //int numberInt = int.Parse(number);

            //int sum = 0;
            //for(int i = 1; i <= numberInt; i++)
            //{
            //    if(i % 2 == 0)
            //    {
            //        sum += i;
            //    }
            //}
            //Console.WriteLine("Deer User, the sum of all numbers from 0 to " + numberInt + " is " + sum);
            #endregion

            #region Switch

            //Console.Write("Deer User, please, input your favourite season: ");

            //string favSeason = Console.ReadLine();

            //switch (favSeason.Trim().ToLower())
            //{
            //    case "spring":
            //        Console.WriteLine("Yes, spring is amazing");
            //        break;
            //    case "summer":
            //        Console.WriteLine("Yes, summer is too good to be true");
            //        break;
            //    case "autumn":
            //        Console.WriteLine("Fall is autumn also");
            //        break;
            //    case "winter":
            //        Console.WriteLine("Winter is coming, baby");
            //        break;
            //    default:
            //        Console.WriteLine("Anqut kusu, duzgun fesil yazjksdvkjsvh");
            //        break;
            //}

            #endregion

            //byte age = 255;
            //int id = 0;

            //Console.WriteLine(sizeof(byte));
            //Console.WriteLine(sizeof(int));

            //Console.WriteLine(FindPower(5, 3));
            //Console.WriteLine(FindPower(10, 5));

            Console.Write("Dear user, input your email: ");

            string userEmail = Console.ReadLine();

            if(IsValidEmail(userEmail))
            {
                Console.WriteLine("Thank you. we have sent verification email to your address.");
            }
            else
            {
                Console.WriteLine("Please, input a valid email address.");
            }
        }

        static bool IsValidEmail(string email)
        {
            if(email.IndexOf('@') == -1)
            {
                return false;
            }

            return true;
        }

        static int FindPower(int a, int b)
        {
            int result = 1;
            for (int i = 0; i < b; i++)
            {
                result *= a;
            }

            return result;
        }

    }
}
